# 236369-HW4
 WWW course - final project - telegram polls bot


INIT:

start client -
    cd client
    npm start

start server - 
    cd flask-server
    flask run